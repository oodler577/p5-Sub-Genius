package Sub::Genius::Util;

use strict;
use warnings;

use parent q{Sub::Genius};
use Util::H2O::More qw/ddd/;

# dispatch for invocation method
my $invocation = {
    any  => \&_as_any,     # invoke plan with run_any
    all  => \&_as_all,     # invoke plan with loop using `next` + run_once
    once => \&_as_once,    # invoke plan without dependency on Sub::Genius
};

sub _as_once {
    return qq{
 ## initialize Sub::Genius (caching 'on' by default)
 my \$sq = Sub::Genius->new(preplan => qq{\$preplan} );
 \$sq->init_plan;
 my \$final_scope = \$sq->run_once( scope => {}, ns => q{main}, verbose => 1);};
}

sub _as_any {
    return qq{
 ## initialize Sub::Genius (caching 'on' by default)
 my \$final_state = Sub::Genius->new(preplan => qq{\$preplan})->run_any( scope => {}, ns => q{main}, verbose => 1);};
}

sub _as_all {
    return qq/
 ## initialize Sub::Genius (caching 'on' by default)
 my \$sq = Sub::Genius->new(preplan => qq{\$preplan} );
 \$sq->init_plan;
 do {
   my \$final_scope = \$sq->run_once( scope => {}, ns => q{main}, verbose => 1);
 }
 while (\$sq->next);
/
}

sub export_as {
    my ( $self, %opts ) = @_;

    die qq{'preplan' and 'prefile' are mutually exclusive\n} if ( $opts{preplan} and $opts{prefile} );

    if ( defined $opts{prefile} ) {
        local $/ = undef;
        open my $ph, q{<}, $opts{prefile} || die $!;
        $opts{preplan} = <$ph>;
        close $ph;
    }

    my $sq = $self->new(%opts);
    $sq->init_plan;
    print $sq->dfa->as_graphviz; # this is a minimal DFA

    return;
}

sub list {
    my ( $self, %opts ) = @_;

    die qq{'preplan' and 'prefile' are mutually exclusive\n} if ( $opts{preplan} and $opts{prefile} );

    if ( defined $opts{prefile} ) {
        local $/ = undef;
        open my $ph, q{<}, $opts{prefile} || die $!;
        $opts{preplan} = <$ph>;
        close $ph;
    }

    my $sq = $self->new(%opts);
    $sq->init_plan;

    while (my $preplan = $sq->next) {
      print qq{$preplan\n};
    }

    return;
}

sub subs2perl {
    my ( $self, %opts ) = @_;

    die qq{'preplan' and 'prefile' are mutually exclusive\n} if ( $opts{preplan} and $opts{prefile} );

    if ( defined $opts{prefile} ) {
        local $/ = undef;
        open my $ph, q{<}, $opts{prefile} || die $!;
        $opts{preplan} = <$ph>;
        close $ph;
    }

    # PRE is parsed, but not converted to validate it
    my $sq = $self->new(%opts);

    my @subs       = split /[^\w]/, $opts{preplan};
    my @pre_tokens = ();
    my @perlsubpod = ();

    # make sure subs are not repeated
    my %uniq = ();
    foreach my $sub ( @subs ) {
        ++$uniq{$sub};
    }
    delete $uniq{q{}} if $uniq{q{}};

    @subs          = ();
  SUBS:
    foreach my $sub ( keys %uniq ) {
        push @subs,       $sub;
        push @pre_tokens, $sub;
        push @perlsubpod, qq{ =item * C<$sub>\n};
    }

    my $perlsub    = $self->_dump_subs( \@subs );

    my $perlpre    = $opts{preplan};
    $perlpre =~ s/\n$//;
    $perlpre =~ s/^/  /gm; 
    my $perlsubpod = join( qq{\n}, @perlsubpod );
    my $invokemeth = $invocation->{ $opts{q{with-run}} }->();

    my $perl = qq{#!/usr/bin/env perl
 use strict;
 use warnings;
 use feature 'state';

 use Sub::Genius ();

 my \$preplan = q{
$perlpre
 };

 ## intialize hash ref as container for global memory
 my \$GLOBAL = {};
 
$invokemeth

$perlsub
 exit;

__END__

=encoding UTF-8

=head1 NAME

Sub::Genius::Util - Utility helpers for generating Perl code from Sub::Genius plans

=head1 SYNOPSIS

This module is primarily intended for use with the C<stubby> utility.
Please refer to that script for a concrete, end-to-end example of how
these helpers are used in practice.

That said, C<Sub::Genius::Util> can be used directly to generate Perl
code skeletons or fully expanded scripts derived from a Sub::Genius
execution plan.

=head1 DESCRIPTION

C<Sub::Genius::Util> provides helper routines for dumping Perl source
code that corresponds to a Sub::Genius execution plan (a PRE).

Its primary purpose is to help bootstrap scripts or modules by
generating:

=over 4

=item *
Skeleton subroutines implied by a plan

=item *
Standalone Perl scripts that do not depend on C<Sub::Genius> at runtime

=item *
Explicit, linearized execution flows derived from PRE expressions

=back

This is particularly useful when you want to:

=over 4

=item *
Inspect or audit the execution order implied by a PRE

=item *
Generate a starting point for a hand-written script or module

=item *
Eliminate runtime dependency on C<Sub::Genius> after planning is complete

=back

In most cases, these utilities are used as one-liners during development
or build steps, rather than as part of a long-running application.

=head2 Generated Subroutine Shape

When generating code that defines subroutines implied by a plan, each
subroutine takes approximately the following form:

    sub C {
      my $scope      = shift;    # execution context passed by Sub::Genius::run_once
      state $mystate = {};       # persists across calls
      my    $myprivs = {};       # lexical scratch space, discarded on exit

      # --- begin subroutine implementation here ---
      print qq{Sub C: placeholder implementation\n};

      # return updated scope for the next step
      return $scope;
    }

This reflects the calling convention used internally by
C<Sub::Genius::run_once>, where a mutable C<$scope> hashref is threaded
through each step in sequence.

=head1 METHODS

=head2 subs2perl

Generates Perl subroutine definitions corresponding to a set of symbols
in a plan.

This method exists to support utilities that initialize or scaffold a
script or module intended to be run under C<Sub::Genius>. The generated
code is intended as a starting point and typically requires manual
editing.

=head2 plan2nodeps

Given a PRE, generates a standalone Perl script that reproduces the
execution order implied by the plan I<without> requiring C<Sub::Genius>
at runtime.

This is useful when you want to “compile” a plan into plain Perl.

Example:

    $ perl -MSub::Genius::Util \
      -e 'print Sub::Genius::Util->plan2nodeps(plan => q{A&B&C&D&E&F&G})' \
      > my-script.pl

The generated script explicitly performs what
C<Sub::Genius::run_once> would normally do dynamically:

    my $scope = {};
    $scope = G($scope);
    $scope = D($scope);
    $scope = F($scope);
    $scope = B($scope);
    $scope = E($scope);
    $scope = H($scope);
    $scope = C($scope);
    $scope = A($scope);

This makes execution order visible, debuggable, and independent of the
planning engine.

=head2 precache

Accepts parameters for invoking C<Sub::Genius>'s caching mechanism and
returns a properly initialized C<Sub::Genius> instance.

Because this delegates to Sub::Genius’s native caching behavior, a given
PRE will not be repeatedly cached unless explicitly forced. This helper
exists primarily to centralize cache setup and option handling in tools
that build on Sub::Genius.

=head1 DESIGN NOTES

This module is intentionally narrow in scope.

It does not attempt to provide a public API suitable for general-purpose
use, nor does it hide the mechanics of what it generates. Instead, it
aims to:

=over 4

=item *
Make Sub::Genius plans concrete and inspectable

=item *
Support tooling and bootstrapping workflows

=item *
Favor transparency over abstraction

=back

If you find yourself calling these methods repeatedly at runtime, you
may want to reconsider whether code generation is the right tool for
your use case.

=head1 SEE ALSO

L<Sub::Genius>

=head1 COPYRIGHT AND LICENSE

Same terms as Perl itself.

=head1 AUTHOR

OODLER 577 E<lt>oodler@cpan.orgE<gt>
